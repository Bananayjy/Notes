package com.yjy.tts.product.mapper;

import com.yjy.tts.product.entity.AttrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品属性
 * 
 * @author yjy
 * @email 2322092442@qq.com
 * @date 2024-02-24 14:16:32
 */
@Mapper
public interface AttrMapper extends BaseMapper<AttrEntity> {
	
}
